"""Paired operating differences and complete-session bootstrap intervals."""

import numpy as np
from .metrics import report

METRICS = (
    "mAP",
    "acc_bal",
    "macro_F1",
    "mean_signal_recall",
    "recall_RR",
    "recall_RG",
    "recall_NoR",
    "precision_RR",
    "precision_RG",
)


def paired_comparison(labels, baseline, candidate, sessions=None, repetitions=2000):
    labels, baseline, candidate = map(np.asarray, (labels, baseline, candidate))
    if baseline.shape != candidate.shape or baseline.shape != (len(labels), 3):
        raise ValueError("Paired comparison requires aligned three-class logits")
    old, new = report(labels, baseline), report(labels, candidate)
    deltas = {k: float(new["metrics"][k] - old["metrics"][k]) for k in METRICS}
    failures = [k for k in ("mAP", "acc_bal", "macro_F1", "recall_RR", "recall_RG") if deltas[k] < -1e-12]
    failures += [k for k in ("recall_NoR", "precision_RR", "precision_RG") if deltas[k] < -0.02 - 1e-12]
    if deltas["mean_signal_recall"] < 0.01 - 1e-12:
        failures.append("mean_signal_recall_gain_below_1pp")
    transitions = []
    for true in range(3):
        mask = labels == true
        transitions.append(
            np.bincount(3 * baseline[mask].argmax(1) + candidate[mask].argmax(1), minlength=9)
            .reshape(3, 3)
            .tolist()
        )
    result = dict(
        baseline=old,
        candidate=new,
        delta=deltas,
        passes_broad_gate=not failures,
        failures=failures,
        paired_prediction_transitions=transitions,
    )
    if sessions is not None:
        sessions = np.asarray(sessions)
        if len(sessions) != len(labels):
            raise ValueError("Session membership must align with predictions")
        groups = [np.flatnonzero(sessions == s) for s in np.unique(sessions)]
        rng = np.random.default_rng(20261007)
        samples = {k: [] for k in METRICS}
        for _ in range(repetitions):
            idx = np.concatenate([groups[i] for i in rng.integers(len(groups), size=len(groups))])
            if len(np.unique(labels[idx])) != 3:
                continue
            a, b = (
                report(labels[idx], baseline[idx])["metrics"],
                report(labels[idx], candidate[idx])["metrics"],
            )
            for k in METRICS:
                samples[k].append(b[k] - a[k])
        result["session_bootstrap"] = dict(
            seed=20261007,
            sessions=len(groups),
            repetitions=repetitions,
            valid_repetitions=len(samples["mAP"]),
            confidence=0.95,
            intervals={k: np.quantile(v, [0.025, 0.975]).tolist() if v else None for k, v in samples.items()},
        )
    else:
        result["uncertainty_scope"] = (
            "Paired counts only; trustworthy independent scene/session groups unavailable."
        )
    return result
