"""Raw-validation operating gates, shared by training and experiment reports."""

import math
import numpy as np


def operating(report):
    cm = np.asarray(report["confusion_matrix"], dtype=float)
    recalls = np.divide(cm.diagonal(), cm.sum(1), out=np.zeros(3), where=cm.sum(1) > 0)
    precision = np.divide(cm.diagonal(), cm.sum(0), out=np.zeros(3), where=cm.sum(0) > 0)
    city_scores = [
        m["mean_signal_recall"]
        for m in report.get("slices", {}).get("city", {}).values()
        if math.isfinite(m.get("mean_signal_recall", float("nan")))
    ]
    return dict(
        mAP=report["metrics"]["mAP"],
        recall_RR=float(recalls[0]),
        recall_RG=float(recalls[1]),
        recall_NoR=float(recalls[2]),
        precision_RR=float(precision[0]),
        precision_RG=float(precision[1]),
        mean_signal_recall=float(recalls[:2].mean()),
        worst_city_signal_recall=min(city_scores) if city_scores else float(recalls[:2].mean()),
    )


def recall_selection(report, reference, tolerance=0.02):
    current = operating(report)
    floors = {key: reference[key] for key in ("recall_RR", "recall_RG", "mAP", "worst_city_signal_recall")}
    floors.update({key: reference[key] - tolerance for key in ("recall_NoR", "precision_RR", "precision_RG")})
    failures = [
        key
        for key, floor in floors.items()
        if not math.isfinite(current[key]) or current[key] + 1e-12 < floor
    ]
    key = (current["mean_signal_recall"], current["worst_city_signal_recall"], current["mAP"])
    return not failures, key, failures
