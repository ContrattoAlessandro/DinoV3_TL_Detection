"""Recall pilot invariants: compatibility, independent evidence and honest gates."""

import copy
import argparse
import json
from pathlib import Path
import numpy as np
import pytest
import torch
from torch.nn import functional as F
from PIL import Image

from dinov3_global.head import EvidenceMILHead, RGBEvidenceMILHead
from dinov3_global.losses import token_losses
from dinov3_global.metrics import report, to_jsonable
from dinov3_global.preprocessing import rasterize_attributes
from dinov3_global.selection import operating, recall_selection
from dinov3_global.comparison import paired_comparison
from scripts.recall_pilot import warm_start, variant_config, advances
from dinov3_global.config import load_config
from dinov3_global.data import DTLDGlobalDataset
from dinov3_global.dtld import FrameSample


@pytest.fixture(autouse=True)
def small_cpu_thread_pool():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)


def pair():
    torch.manual_seed(8)
    kwargs = dict(in_dim=16, proj_dim=16, grid_hw=(2, 3), dropout=0, context_dropout=0)
    original = EvidenceMILHead(**kwargs).eval()
    enhanced = RGBEvidenceMILHead(**kwargs).eval()
    warm_start(enhanced, original.state_dict())
    return original, enhanced


def test_zero_residual_equivalence_and_semantic_relevance():
    original, enhanced = pair()
    patches, cls = torch.randn(2, 6, 16), torch.randn(2, 16)
    image = torch.rand(2, 3, 32, 48)
    expected, aux = original(patches, cls)
    actual, new_aux = enhanced(patches, cls, images=image)
    assert torch.equal(expected, actual)
    for key in aux["maps"]:
        assert torch.equal(aux["maps"][key], new_aux["maps"][key])
    with torch.no_grad():
        enhanced.rgb_residual[-1].weight.fill_(1)
    _, changed = enhanced(patches, cls, images=image)
    assert torch.equal(aux["maps"]["rel_logit"], changed["maps"]["rel_logit"])
    assert changed["rgb_lamp_correction"].abs().max() <= 3
    assert changed["rgb_state_correction"].abs().max() <= 1
    with pytest.raises(ValueError, match="aligned"):
        enhanced(patches, cls)
    bad = dict(original.state_dict())
    bad.pop("lamp.weight")
    with pytest.raises(ValueError, match="Incompatible"):
        warm_start(enhanced, bad)


def test_rgb_encoder_receives_gradients_after_zero_initialized_output_updates():
    _, head = pair()
    head.train()
    optimizer = torch.optim.AdamW(head.parameters(), lr=0.01)
    for _ in range(2):
        optimizer.zero_grad()
        logits, _ = head(torch.randn(2, 6, 16), torch.randn(2, 16), images=torch.rand(2, 3, 32, 48))
        F.cross_entropy(logits, torch.tensor([0, 1])).backward()
        optimizer.step()
    assert head.rgb_encoder[0].weight.grad.abs().sum() > 0


def targets(boxes, states, relevance, shape=(32, 64)):
    result = rasterize_attributes(
        np.asarray(boxes),
        relevance,
        states,
        [1] * len(boxes),
        [5] * len(boxes),
        shape,
        np.ones((shape[0] // 16, shape[1] // 16), bool),
    )
    return {k: torch.from_numpy(v).unsqueeze(0) for k, v in result.items()}


def loss_inputs(t):
    b, h, w = t["lamp"].shape
    maps = dict(
        lamp_logit=torch.zeros(b, h * w, requires_grad=True),
        rel_logit=torch.zeros(b, h * w, requires_grad=True),
        state_logit=torch.zeros(b, h * w, 6, requires_grad=True),
    )
    kw = dict(
        w_state=0,
        w_rel=0,
        reduction="instance",
        instance_id=t["instance_id"],
        valid_masks={k: v for k, v in t.items() if k.endswith("_valid")},
        instance_weights={k[:-16]: v for k, v in t.items() if k.endswith("_instance_weight")},
    )
    return maps, kw


def test_lamp_mass_is_resolution_independent_and_empty_groups_renormalize():
    losses = []
    for shape in ((32, 64), (32, 128)):
        t = targets([[1, 1, 15, 15]], [2], [1], shape)
        maps, kw = loss_inputs(t)
        maps["lamp_logit"] = torch.where(
            t["lamp"].flatten(1) > 0, -torch.ones_like(maps["lamp_logit"]), maps["lamp_logit"]
        )
        value = token_losses(
            maps, t["lamp"], t["valid"], t["state"], t["rel"], w_lamp=1, lamp_positive_fraction=0.25, **kw
        )
        losses.append(value["lamp"])
    expected = 0.25 * F.softplus(torch.tensor(1.0)) + 0.75 * F.softplus(torch.tensor(0.0))
    assert torch.allclose(losses[0], expected) and torch.equal(losses[0], losses[1])
    t = targets([], [], [])
    maps, kw = loss_inputs(t)
    value = token_losses(
        maps, t["lamp"], t["valid"], t["state"], t["rel"], w_lamp=1, lamp_positive_fraction=0.25, **kw
    )
    assert torch.allclose(value["lamp"], torch.log(torch.tensor(2.0)))


def test_joint_evidence_masks_conflicts_and_has_gate_gradients():
    # A relevant RR, relevant green, irrelevant red, and relevant off lamp.
    t = targets(
        [[1, 1, 15, 15], [17, 1, 31, 15], [33, 1, 47, 15], [49, 1, 63, 15]], [2, 0, 2, 1], [1, 1, 0, 1]
    )
    maps, kw = loss_inputs(t)
    value = token_losses(maps, t["lamp"], t["valid"], t["state"], t["rel"], w_lamp=0, w_evidence=1, **kw)
    value["total"].backward()
    assert all(maps[k].grad.abs().sum() > 0 for k in maps)
    assert torch.isfinite(value["evidence"])
    conflict = targets([[1, 1, 15, 15], [1, 1, 15, 15]], [0, 2], [1, 1])
    maps, kw = loss_inputs(conflict)
    value = token_losses(
        maps,
        conflict["lamp"],
        conflict["valid"],
        conflict["state"],
        conflict["rel"],
        w_lamp=0,
        w_evidence=1,
        **kw,
    )
    assert value["total"] == 0
    value["total"].backward()
    assert maps["state_logit"].grad is None or maps["state_logit"].grad.abs().sum() == 0


def test_selection_rejects_mean_gain_that_hides_recall_loss():
    y = np.array([0, 0, 1, 1, 2, 2])
    baseline = report(y, np.eye(3)[[0, 0, 1, 0, 2, 2]] * 5, cities=["x"] * 6)
    candidate = report(y, np.eye(3)[[0, 1, 1, 1, 2, 2]] * 5, cities=["x"] * 6)
    eligible, _, failures = recall_selection(candidate, operating(baseline))
    assert not eligible and "recall_RR" in failures
    eligible, _, failures = recall_selection(baseline, operating(baseline))
    assert eligible and not failures
    rep = dict(eligible=True, epoch=0, selection_key=[0.9], baseline=dict(mean_signal_recall=0.9))
    assert not advances(rep, rep)


def test_checkpoint_report_supports_weights_only_loading(tmp_path):
    y = np.tile([0, 1, 2], 10)
    rep = report(y, np.eye(3)[y] * 5, cities=np.asarray(["city"] * len(y)))
    path = tmp_path / "best.pt"
    torch.save(dict(report=to_jsonable(rep), head=dict(weight=torch.ones(1))), path)
    restored = torch.load(path, weights_only=True)
    assert restored["report"]["confusion_matrix"] == rep["confusion_matrix"]
    assert restored["report"]["metrics"]["mAP"] == rep["metrics"]["mAP"]
    assert torch.equal(restored["head"]["weight"], torch.ones(1))


def test_factorial_configs_and_paired_bootstrap():
    cfg = load_config("configs/backbone_vitb.yaml")
    original = copy.deepcopy(cfg)
    ref = dict(mAP=0.7)
    for v in ("control", "supervision", "rgb", "combined"):
        new = variant_config(cfg, v, ref, 0)
        assert (new["decoder"]["head"] == "v8_rgb_evidence") == (v in ("rgb", "combined"))
        assert (new["loss"].get("token_evidence", 0) == 0.1) == (v in ("supervision", "combined"))
    assert cfg == original
    y = np.tile([0, 1, 2], 3)
    logits = np.eye(3)[y] * 5
    comparison = paired_comparison(y, logits, logits, sessions=np.repeat([0, 1, 2], 3), repetitions=12)
    assert all(v == [0.0, 0.0] for v in comparison["session_bootstrap"]["intervals"].values())
    assert not comparison["passes_broad_gate"]


@pytest.mark.parametrize("improve", [False, True])
def test_study_cannot_launch_replication_or_external_tests_before_gates(tmp_path, monkeypatch, improve):
    import scripts.recall_pilot as pilot

    (tmp_path / "plan.json").write_text(json.dumps(dict(inputs_sha256={})))
    calls = []

    class Child:
        pid = 123

        def __init__(self, argv, **kwargs):
            calls.append(argv)
            assert "--stage" in argv and argv[argv.index("--stage") + 1] == "train"
            directory = Path(argv[argv.index("--out") + 1])
            variant = argv[argv.index("--variant") + 1]
            directory.mkdir(parents=True, exist_ok=True)
            cell = dict(
                eligible=True,
                epoch=int(improve and variant != "control"),
                selection_key=[0.91 if improve and variant != "control" else 0.9, 0.8, 0.7],
                baseline=dict(mean_signal_recall=0.9),
            )
            (directory / "cell_report.json").write_text(json.dumps(cell))

        def wait(self):
            return 0

    monkeypatch.setattr(pilot.subprocess, "Popen", Child)
    monkeypatch.setattr(pilot, "benchmark", lambda *args: dict(passes=False))
    pilot.study(argparse.Namespace(out=tmp_path, resume=True))
    assert len(calls) == 4
    decision = json.loads((tmp_path / "decision.json").read_text())
    assert decision["promote"] is False
    assert ("latency" in decision["reason"]) == improve
    assert json.loads((tmp_path / "status.json").read_text())["state"] == "complete"


def test_target_size_uses_relevant_compatible_lamp_in_mixed_state_scene(tmp_path):
    (tmp_path / "train").mkdir()
    Image.new("RGB", (2048, 1024)).save(tmp_path / "train/frame.jpg")
    frame = FrameSample(
        "./City/route/session/frame.tiff",
        np.array([[100, 100, 104, 112], [500, 500, 600, 700]], np.float32),
        np.array([1, 1]),
        np.array([1, 1]),
        np.array([2, 0]),
        np.array([5, 5]),
        ["a", "b"],
    )
    item = dict(
        entry=dict(image_path=frame.image_path),
        frame=frame,
        y=0,
        weight=1.0,
        city="City",
        n_lamps=2,
        max_lamp_h=200.0,
    )
    ds = DTLDGlobalDataset("unused", str(tmp_path), "train", items=[item])
    sample = ds[0]
    assert sample["max_lamp_h"].item() == 125.0
    assert sample["target_lamp_h"].item() == 7.5
    item["y"] = 2
    assert ds[0]["target_lamp_h"].item() == -1.0
