"""Resumable four-way head pilot; validation gates precede folds and external tests.

Run --stage study for the full authorized protocol, or --stage train for one cell.
All artifacts go to a NEW directory; original checkpoints and reports are read-only.
"""

import argparse
import copy
import csv
from datetime import datetime, timezone
import gc
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader
import yaml

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "src"))
from dinov3_global.comparison import paired_comparison
from dinov3_global.config import validate_config
from dinov3_global.data import DTLDGlobalDataset, class_frequencies, collate_global
from dinov3_global.engine import _build_model, dataset_options, fit, load_model, set_seed, _pseudo_flags
from dinov3_global.evaluation import sha256_file, write_json
from dinov3_global.metrics import report, to_jsonable
from dinov3_global.preprocessing import preprocess_for_config
from dinov3_global.runtime import loader_kwargs, set_training_threads, validate_runtime
from dinov3_global.selection import operating, recall_selection
from dinov3_global.validation import fold_manifest
from scripts.backbone_pilot import aligned_predictions, published_vzc_predictions

VARIANTS = ("control", "supervision", "rgb", "combined")
BASELINE = REPO / "runs/backbone_vitb_fold0/training/fold0/best.pt"
REFERENCE_RESULTS = REPO / "runs/backbone_vitb_fold0/evaluations"


def now():
    return datetime.now(timezone.utc).isoformat()


def variant_config(base, variant, reference, seed):
    cfg = copy.deepcopy(base)
    if variant not in VARIANTS:
        raise ValueError("Unknown pilot variant")
    cfg["optim"].update(
        seed=seed,
        epochs=6,
        warmup_epochs=1,
        early_stop_patience=2,
        lr=1e-5,
        rgb_lr=6e-5,
        early_stop_metric="constrained_signal_recall",
        selection_reference=reference,
    )
    # The starting head already completed consistency warm-up.
    cfg["loss"]["consist_warmup_epochs"] = 0
    if variant in ("rgb", "combined"):
        cfg["decoder"].update(head="v8_rgb_evidence", rgb_lamp_bound=3.0, rgb_state_bound=1.0)
    if variant in ("supervision", "combined"):
        cfg["loss"].update(lamp_positive_fraction=0.25, lamp_pos_weight=1.0, token_evidence=0.1)
    validate_config(cfg)
    return cfg


def warm_start(head, source):
    """Permit ONLY newly introduced RGB tensors; retain strict old-head loading."""
    missing, unexpected = head.load_state_dict(source, strict=False)
    if unexpected or any(not key.startswith("rgb_") for key in missing):
        raise ValueError(f"Incompatible warm-start tensors: {missing}, {unexpected}")
    if not getattr(head, "requires_rgb", False) and missing:
        raise ValueError("Incomplete original head")


def load_npz(path):
    with np.load(path, allow_pickle=False) as saved:
        return {key: saved[key] for key in saved.files}


def verify_plan(path):
    frozen = json.loads(path.read_text(encoding="utf-8"))
    for name, expected in frozen["inputs_sha256"].items():
        if sha256_file(REPO / name) != expected:
            raise ValueError(f"Frozen study input changed: {name}; use a new experiment directory")
    return frozen


def train_cell(args):
    if args.plan:
        verify_plan(args.plan)
    completed = args.out / "cell_report.json"
    if completed.exists():
        if not args.resume:
            raise ValueError("Completed cell exists; use --resume")
        return
    state = torch.load(args.baseline, map_location="cpu", weights_only=True)
    if state["cfg"]["decoder"]["head"] != "v7_evidence" or state["cfg"]["backbone"]["dim"] != 768:
        raise ValueError("Pilot baseline must be a frozen ViT-B original evidence head")
    if (
        args.fold == 0
        and args.seed == 0
        and (state["epoch"] != 7 or args.baseline.resolve() != BASELINE.resolve())
    ):
        raise ValueError("Initial pilot must use the retained epoch-7 fold-0 checkpoint")
    predictions_path = args.baseline.parent / "val_predictions.npz"
    predictions = load_npz(predictions_path)
    baseline_report = report(predictions["labels"], predictions["logits"], cities=predictions["cities"])
    reference = operating(baseline_report)
    cfg = variant_config(state["cfg"], args.variant, reference, args.seed)
    d = cfg["data"]
    full = DTLDGlobalDataset(
        str(REPO / d["label_dir"]),
        str(REPO / d["img_root"]),
        "train",
        target_hw=tuple(d["target_hw"]),
        **dataset_options(cfg),
    )
    manifest = json.loads((REPO / "metadata/dtld_city_folds.json").read_text())
    actual = fold_manifest(
        full.items,
        [f["val_cities"] for f in manifest["folds"]],
        d,
        sha256_file(REPO / d["label_dir"] / "DTLD_train.json"),
    )
    for key in ("annotation_sha256", "items_sha256", "n_items", "folds"):
        if actual[key] != manifest[key]:
            raise ValueError("City-fold membership changed")
    cities = set(manifest["folds"][args.fold]["val_cities"])
    items = [
        [it for it in full.items if (it["city"] in cities) == validation] for validation in (False, True)
    ]
    expected_names = [Path(it["entry"]["image_path"]).stem for it in items[1]]
    if expected_names != [Path(p).stem for p in predictions["paths"]] or not np.array_equal(
        predictions["labels"], [it["y"] for it in items[1]]
    ):
        raise ValueError("Baseline validation predictions do not match this fold")
    runtime = validate_runtime(json.loads((REPO / "configs/runtime.json").read_text()))
    datasets = [
        DTLDGlobalDataset(
            str(REPO / d["label_dir"]),
            str(REPO / d["img_root"]),
            "train",
            train=i == 0,
            target_hw=tuple(d["target_hw"]),
            items=subset,
            **dataset_options(cfg),
        )
        for i, subset in enumerate(items)
    ]
    loaders = [
        DataLoader(ds, batch_size=4, shuffle=i == 0, collate_fn=collate_global, **loader_kwargs(cfg, runtime))
        for i, ds in enumerate(datasets)
    ]
    args.out.mkdir(parents=True, exist_ok=True)
    frozen = dict(
        config=cfg,
        baseline_sha256=sha256_file(args.baseline),
        validation_predictions_sha256=sha256_file(predictions_path),
        fold=args.fold,
        audit=actual["folds"][args.fold],
    )
    frozen_path = args.out / "cell_plan.json"
    if frozen_path.exists() and json.loads(frozen_path.read_text()) != frozen:
        raise ValueError("Cell inputs/configuration changed")
    write_json(frozen_path, frozen)
    dev = torch.device("cuda")
    set_seed(args.seed)
    model = _build_model(cfg, dev, str(REPO))
    warm_start(model.head, state["ema"])
    initial_key = (reference["mean_signal_recall"], reference["worst_city_signal_recall"], reference["mAP"])
    resume = dict(best_init=initial_key[0], selection_key_init=initial_key)
    last_path = args.out / "last.pt"
    if last_path.exists():
        if not args.resume:
            raise ValueError("Training artifacts exist; use --resume")
        last = torch.load(last_path, map_location="cpu", weights_only=True)
        if last["cfg"] != cfg:
            raise ValueError("Resume configuration changed")
        model.head.load_state_dict(last["head"], strict=True)
        resume.update(
            start_ep=last["epoch"],
            opt_state=last["opt"],
            scaler_state=last["scaler"],
            ema_state=last["ema"],
            rng_state=last["rng_state"],
            best_init=last["best_score"],
            stale_init=last["stale_epochs"],
            selection_key_init=last["selection_key"],
        )
    elif (args.out / "history.jsonl").exists():
        raise ValueError("History exists without a resumable checkpoint")
    else:
        initial = dict(
            head=copy.deepcopy(model.head.state_dict()),
            ema=copy.deepcopy(model.head.state_dict()),
            cfg=cfg,
            epoch=0,
            metrics=to_jsonable(baseline_report["metrics"]),
            report=to_jsonable(baseline_report),
            best_score=initial_key[0],
            selection_metric="constrained_signal_recall",
            selection_key=list(initial_key),
            stale_epochs=0,
        )
        torch.save(initial, args.out / "best.pt")
        np.savez_compressed(args.out / "val_predictions.npz", **predictions)
    set_training_threads(runtime)
    set_seed(args.seed)
    log_pi = torch.log(torch.tensor(class_frequencies(datasets[0]), dtype=torch.float32) + 1e-8)
    if not (args.out / "STOPPED").exists():
        fit(
            cfg,
            model,
            *loaders,
            str(args.out),
            dev,
            log_pi,
            pseudo_flags=_pseudo_flags(datasets[1]),
            **resume,
        )
    chosen = torch.load(args.out / "best.pt", map_location="cpu", weights_only=True)
    best = load_npz(args.out / "val_predictions.npz")
    final_report = report(
        best["labels"],
        best["logits"],
        cities=best["cities"],
        target_lamp_h=best.get("target_lamp_h"),
        max_lamp_h=best.get("max_lamp_h"),
    )
    if final_report["confusion_matrix"] != chosen["report"]["confusion_matrix"] or not np.isclose(
        final_report["metrics"]["mAP"], chosen["metrics"]["mAP"], rtol=0, atol=1e-12
    ):
        raise ValueError("Best checkpoint and validation prediction artifacts disagree")
    eligible, key, failures = recall_selection(final_report, reference)
    write_json(
        completed,
        dict(
            status="complete",
            variant=args.variant,
            fold=args.fold,
            seed=args.seed,
            epoch=chosen["epoch"],
            eligible=eligible,
            selection_key=list(key),
            failures=failures,
            baseline=reference,
            report=final_report,
            checkpoint_sha256=sha256_file(args.out / "best.pt"),
        ),
    )


def advances(candidate, control):
    return (
        candidate["eligible"]
        and candidate["epoch"] > 0
        and candidate["selection_key"][0]
        > max(control["selection_key"][0], candidate["baseline"]["mean_signal_recall"]) + 1e-12
    )


def benchmark(candidate, out):
    torch.set_num_threads(1)
    timing_source = json.loads((REPO / "docs/experiments/backbone_capacity/results/latency.json").read_text())
    paths = [REPO / "datasets/DTLD_jpg/train" / name for name in timing_source["input_sha256"]]
    for path in paths:
        if sha256_file(path) != timing_source["input_sha256"][path.name]:
            raise ValueError("Latency input changed")
    results = {}
    for name, checkpoint in (("baseline", BASELINE), ("candidate", candidate)):
        model, cfg, _ = load_model(str(checkpoint), str(REPO), torch.device("cuda"))
        samples = []
        for i in range(35):
            torch.cuda.synchronize()
            started = time.perf_counter()
            tensor, _, metadata = preprocess_for_config(paths[i % len(paths)], cfg)
            x = tensor.unsqueeze(0).cuda().float() / 255
            kw = {k: v.unsqueeze(0).cuda() for k, v in metadata.items()}
            with torch.inference_mode(), torch.autocast("cuda"):
                model(x, **kw)["logits"].softmax(-1).cpu()
            torch.cuda.synchronize()
            elapsed = (time.perf_counter() - started) * 1000
            if i >= 5:
                samples.append(elapsed)
        results[name] = dict(
            samples_ms=samples, median_ms=float(np.median(samples)), p95_ms=float(np.quantile(samples, 0.95))
        )
        del model
        gc.collect()
        torch.cuda.empty_cache()
    results["passes"] = results["candidate"]["median_ms"] <= 1.10 * results["baseline"]["median_ms"]
    results["scope"] = (
        "Batch 1: decode, letterbox, transfers, complete forward, softmax, CPU output; 5 warmups, 30 samples."
    )
    results["input_sha256"] = timing_source["input_sha256"]
    write_json(out, results)
    return results


def csv_predictions(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    return dict(
        paths=np.array([r["file"] for r in rows]),
        labels=np.array([("RR", "RG", "NoR").index(r["label"]) for r in rows]),
        logits=np.array([[float(r["logit_" + c]) for c in ("RR", "RG", "NoR")] for r in rows]),
    )


def external_comparison(out):
    old_dtld = load_npz(REFERENCE_RESULTS / "evaluate_dtld_1/predictions.npz")
    old_atlas = csv_predictions(REFERENCE_RESULTS / "evaluate_atlas_1/predictions.csv")
    old_vzc = published_vzc_predictions(
        load_npz(REFERENCE_RESULTS / "evaluate_vzc_tld_1/vitb_fold0/predictions.npz"),
        json.loads((REFERENCE_RESULTS / "evaluate_vzc_tld_1/labels_snapshot.json").read_text()),
    )
    new_vzc = published_vzc_predictions(
        load_npz(out / "external/vzc/candidate/predictions.npz"),
        json.loads((out / "external/vzc/labels_snapshot.json").read_text()),
    )
    pairs = [
        ("DTLD", old_dtld, load_npz(out / "external/dtld/predictions.npz")),
        ("ATLAS", old_atlas, csv_predictions(out / "external/atlas/predictions.csv")),
        ("VZC_TLD", old_vzc, new_vzc),
    ]
    membership = json.loads((out / "external/dtld/membership.json").read_text())["test"]
    sessions_by_stem = {Path(r["image"]).stem: r["session"] for r in membership}
    comparisons = {}
    for name, old, new in pairs:
        labels, aligned = aligned_predictions(name, old, new)
        sessions = [sessions_by_stem[Path(p).stem] for p in old["paths"]] if name == "DTLD" else None
        comparisons[name] = paired_comparison(labels, old["logits"], aligned, sessions=sessions)
    write_json(out / "external_comparison.json", comparisons)
    return all(c["passes_broad_gate"] for c in comparisons.values())


def study(args):
    args.out.mkdir(parents=True, exist_ok=True)
    plan_path = args.out / "plan.json"
    if plan_path.exists():
        if not args.resume:
            raise ValueError("Study exists; use --resume")
        verify_plan(plan_path)
    else:
        if any(args.out.iterdir()):
            raise ValueError("New study output must be empty")
        sources = [
            *sorted((REPO / "src/dinov3_global").glob("*.py")),
            *sorted((REPO / "scripts").glob("*.py")),
        ]
        inputs = [
            BASELINE,
            BASELINE.parent / "val_predictions.npz",
            REPO / "configs/backbone_vitb.yaml",
            REPO / "configs/runtime.json",
            REPO / "metadata/dtld_city_folds.json",
            REPO / "datasets/DTLD/v2.0/DTLD_train.json",
            REPO / "datasets/DTLD/v2.0/DTLD_test.json",
            REPO / "metadata/atlas_labels.json",
            REPO / "datasets/VZC_TLD/download_manifest.json",
            REPO / "metadata/atlas_collection.json",
            REFERENCE_RESULTS / "evaluate_dtld_1/predictions.npz",
            REFERENCE_RESULTS / "evaluate_atlas_1/predictions.csv",
            REFERENCE_RESULTS / "evaluate_vzc_tld_1/vitb_fold0/predictions.npz",
            REFERENCE_RESULTS / "evaluate_vzc_tld_1/labels_snapshot.json",
            *sorted((REPO / "runs/backbones/dinov3_vitb16").glob("*.json")),
            *sorted((REPO / "runs/backbones/dinov3_vitb16").glob("*.safetensors")),
            *sorted((REPO / "datasets/VZC_TLD").glob("**/*annotations*.json")),
        ]
        write_json(
            plan_path,
            dict(
                schema_version=1,
                frozen_at=now(),
                variants=list(VARIANTS),
                max_additional_epochs=6,
                patience=2,
                signal_precision_and_nor_tolerance=0.02,
                external_target_mean_recall_gain=0.01,
                maximum_latency_ratio=1.10,
                inputs_sha256={
                    str(p.relative_to(REPO)).replace("\\", "/"): sha256_file(p) for p in sources + inputs
                },
                protocol="Fold0 factorial pilot -> latency -> other folds and seed1 -> freeze -> external evaluation once",
                transfer_scope="Existing benchmarks informed development; exploratory transfer, DTLD-only fitting.",
            ),
        )
    status_path = args.out / "status.json"
    if status_path.exists() and json.loads(status_path.read_text()).get("state") == "complete":
        return
    status = dict(state="running", started_at=now(), controller_pid=__import__("os").getpid())

    def command(name, argv, done):
        verify_plan(plan_path)
        if done.exists():
            return
        status.update(stage=name, updated_at=now())
        write_json(status_path, status)
        logs = args.out / "logs"
        logs.mkdir(exist_ok=True)
        with (logs / (name + ".log")).open("a", encoding="utf-8") as log:
            process = subprocess.Popen(
                [sys.executable, *map(str, argv)], cwd=REPO, stdout=log, stderr=subprocess.STDOUT
            )
            status.update(child_pid=process.pid)
            write_json(status_path, status)
            code = process.wait()
        if code or not done.exists():
            raise RuntimeError(f"{name} failed, exit {code}; see {logs / (name + '.log')}")
        status.update(child_pid=None)

    def cell(directory, variant, baseline=BASELINE, fold=0, seed=0):
        command(
            directory.replace("/", "_"),
            [
                Path(__file__),
                "--stage",
                "train",
                "--out",
                args.out / directory,
                "--variant",
                variant,
                "--baseline",
                baseline,
                "--fold",
                fold,
                "--seed",
                seed,
                "--plan",
                plan_path,
                "--resume",
            ],
            args.out / directory / "cell_report.json",
        )
        return json.loads((args.out / directory / "cell_report.json").read_text())

    def complete(promote, reason, **extra):
        write_json(
            args.out / "decision.json", dict(promote=promote, reason=reason, retain=str(BASELINE), **extra)
        )
        status.update(state="complete", updated_at=now(), child_pid=None, reason=reason)
        write_json(status_path, status)

    try:
        reports = {v: cell("fold0/" + v, v) for v in VARIANTS}
        write_json(args.out / "pilot_comparison.json", reports)
        eligible = [v for v in VARIANTS[1:] if advances(reports[v], reports["control"])]
        if not eligible:
            complete(
                False,
                "No candidate beats both untouched baseline and matched continuation under validation gates",
            )
            return
        winner = max(eligible, key=lambda v: reports[v]["selection_key"])
        checkpoint = args.out / "fold0" / winner / "best.pt"
        latency_path = args.out / "latency.json"
        latency = (
            json.loads(latency_path.read_text())
            if latency_path.exists()
            else benchmark(checkpoint, latency_path)
        )
        if not latency["passes"]:
            complete(
                False, "Winning validation candidate exceeds 10% inference latency overhead", candidate=winner
            )
            return
        replication = {}
        for fold, seed in ((1, 1), (2, 2), (3, 3), (0, 1)):
            name = f"replication/fold{fold}_seed{seed}"
            baseline_dir = args.out / name / "baseline"
            cfg = yaml.safe_load((REPO / "configs/backbone_vitb.yaml").read_text())
            cfg["optim"]["seed"] = seed - fold
            config_path = args.out / name / "baseline.yaml"
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
            command(
                f"baseline_fold{fold}_seed{seed}",
                [
                    REPO / "scripts/cross_validate.py",
                    "--config",
                    config_path,
                    "--out",
                    baseline_dir,
                    "--fold-indices",
                    fold,
                    "--fold-manifest",
                    REPO / "metadata/dtld_city_folds.json",
                    "--runtime-loader",
                    REPO / "configs/runtime.json",
                    "--resume",
                ],
                baseline_dir / f"fold{fold}/fold_report.json",
            )
            base = baseline_dir / f"fold{fold}/best.pt"
            control = cell(name + "/control", "control", base, fold, seed)
            candidate = cell(name + "/candidate", winner, base, fold, seed)
            replication[name] = dict(control=control, candidate=candidate)
            write_json(args.out / "replication.json", replication)
            if not advances(candidate, control):
                complete(
                    False,
                    "Candidate did not reproduce its gated improvement across cities/seeds",
                    candidate=winner,
                )
                return
        frozen = dict(
            candidate=winner,
            checkpoint=str(checkpoint),
            checkpoint_sha256=sha256_file(checkpoint),
            validation=reports[winner],
            frozen_at=now(),
        )
        frozen_path = args.out / "frozen_candidate.json"
        if frozen_path.exists():
            previous = json.loads(frozen_path.read_text())
            if previous["checkpoint_sha256"] != frozen["checkpoint_sha256"]:
                raise ValueError("Frozen candidate changed after external evaluation")
        else:
            write_json(frozen_path, frozen)
        command(
            "external_dtld",
            [
                REPO / "scripts/evaluate.py",
                "--ckpt",
                checkpoint,
                "--runtime-loader",
                REPO / "configs/runtime.json",
                "--out",
                args.out / "external/dtld",
            ],
            args.out / "external/dtld/report.json",
        )
        command(
            "external_atlas",
            [
                REPO / "scripts/evaluate_ood.py",
                "--ckpt",
                checkpoint,
                "--labels",
                REPO / "metadata/atlas_labels.json",
                "--images",
                REPO / "datasets/atlas_relevance_expanded",
                "--include-uncertain",
                "--out",
                args.out / "external/atlas",
            ],
            args.out / "external/atlas/report.json",
        )
        command(
            "external_vzc",
            [
                REPO / "scripts/evaluate_vzc.py",
                "--ckpt",
                checkpoint,
                "--model-names",
                "candidate",
                "--out",
                args.out / "external/vzc",
            ],
            args.out / "external/vzc/candidate/report.json",
        )
        passes = external_comparison(args.out)
        if passes:
            shutil.copyfile(checkpoint, args.out / "recommended.pt")
        complete(
            passes,
            "Broad external improvement gate passed" if passes else "External broad improvement gate failed",
            candidate=winner,
            checkpoint=str(checkpoint),
            default_config_unchanged=True,
        )
    except Exception as error:
        status.update(state="failed", error=str(error), updated_at=now())
        write_json(status_path, status)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("study", "train"), default="study")
    parser.add_argument("--out", type=Path, default=REPO / "runs/recall_head_pilot")
    parser.add_argument("--baseline", type=Path, default=BASELINE)
    parser.add_argument("--variant", choices=VARIANTS, default="combined")
    parser.add_argument("--fold", type=int, choices=range(4), default=0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    args.out = args.out.resolve()
    if args.stage == "study":
        study(args)
    else:
        train_cell(args)


if __name__ == "__main__":
    main()
