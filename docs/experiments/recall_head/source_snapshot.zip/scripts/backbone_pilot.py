"""Train only fold 0 with ViT-B/16, evaluate three datasets, and compare to C.

The immutable plan records inputs before training. No path in this runner starts
another fold or changes the default model. --resume continues epoch checkpoints
and skips finished stages; interrupted evaluations get fresh output directories.
"""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))
from dinov3_global.backbone import backbone_spec
from dinov3_global.config import load_config
from dinov3_global.evaluation import sha256_file, write_json
from dinov3_global.metrics import report

CONFIG = REPO / "configs/backbone_vitb.yaml"
REFERENCE = REPO / "runs/archive/generalization_study/diagnostic_tests"
DATASETS = {"DTLD": "dtld", "ATLAS": "atlas", "VZC_TLD": "vzc_tld"}


def now():
    return datetime.now(timezone.utc).isoformat()


def aligned_predictions(dataset, reference, candidate):
    """Match exact image identities and labels before comparing scores."""

    def keys(paths):
        return [Path(p).stem if dataset == "DTLD" else str(p).replace("\\", "/") for p in paths]

    old_keys, new_keys = keys(reference["paths"]), keys(candidate["paths"])
    if len(set(old_keys)) != len(old_keys) or len(set(new_keys)) != len(new_keys):
        raise ValueError(f"Duplicate image identities in {dataset}")
    if set(old_keys) != set(new_keys):
        raise ValueError(f"Candidate {dataset} membership differs from the baseline")
    lookup = {key: index for index, key in enumerate(new_keys)}
    indices = [lookup[key] for key in old_keys]
    if not np.array_equal(reference["labels"], candidate["labels"][indices]):
        raise ValueError(f"Candidate {dataset} labels differ from the baseline")
    logits = candidate["logits"][indices]
    if logits.shape != (len(old_keys), 3) or not np.isfinite(logits).all():
        raise ValueError(f"Invalid {dataset} predictions")
    return reference["labels"], logits


def published_vzc_predictions(candidate, snapshot):
    """Select the published test split from the evaluator's train/test output."""
    images = snapshot["images"]
    if candidate["paths"].tolist() != [entry["file"] for entry in images]:
        raise ValueError("VZC predictions differ from the frozen label snapshot")
    if candidate["labels"].tolist() != [entry["label"] for entry in images]:
        raise ValueError("VZC prediction labels differ from the frozen snapshot")
    mask = np.array([entry["split"] == "test" for entry in images])
    return {key: candidate[key][mask] for key in ("paths", "labels", "logits")}


def frozen_inputs(cfg, out):
    snapshot = REPO / cfg["backbone"]["local_ckpt"]
    files = [
        CONFIG,
        REPO / "configs/default.yaml",
        REPO / "configs/runtime.json",
        REPO / "metadata/dtld_city_folds.json",
        REPO / "metadata/atlas_labels.json",
        REPO / "datasets/VZC_TLD/download_manifest.json",
        REPO / "datasets/DTLD/v2.0/DTLD_train.json",
        REPO / "datasets/DTLD/v2.0/DTLD_test.json",
        REPO / "runs/pretrained/experiment_c_fold0.pt",
        REPO / "docs/results/provenance.json",
        REPO / "docs/experiments/generalization/C/fold0/fold_report.json",
        out / "smoke/report.json",
        snapshot / "config.json",
        snapshot / "model.safetensors",
        *sorted((REPO / "src/dinov3_global").glob("*.py")),
        *sorted((REPO / "scripts").glob("*.py")),
    ]
    for dataset, directory in DATASETS.items():
        files.extend(
            [REFERENCE / dataset / "C/predictions.npz", REPO / f"docs/results/{directory}/report.json"]
        )
    return {str(path.relative_to(REPO)).replace("\\", "/"): sha256_file(path) for path in files}


def check_inputs(plan):
    for path, expected in plan["input_sha256"].items():
        if sha256_file(REPO / path) != expected:
            raise ValueError(f"Frozen experiment input changed: {path}")


def last_progress(path):
    with path.open("rb") as stream:
        stream.seek(max(0, path.stat().st_size - 8192))
        lines = stream.read().decode("utf-8", errors="replace").replace("\r", "\n").splitlines()
    return next((line.strip()[:500] for line in reversed(lines) if line.strip()), "")


def run_stage(name, arguments, out, status, plan):
    if name in status["completed_stages"]:
        return
    check_inputs(plan)
    logs = out / "logs"
    logs.mkdir(exist_ok=True)
    attempt = 1
    while (logs / f"{name}_{attempt}.log").exists():
        attempt += 1
    log = logs / f"{name}_{attempt}.log"
    command = [sys.executable, "-u", *map(str, arguments)]
    env = dict(os.environ, HF_HUB_OFFLINE="1", PYTHONUNBUFFERED="1")
    with log.open("wb") as stream:
        child = subprocess.Popen(command, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT, env=env)
        status.update(
            state="running", stage=name, child_pid=child.pid, stage_started_at=now(), command=command
        )
        print(f"{now()} Starting {name} (PID {child.pid})", flush=True)
        while True:
            status.update(updated_at=now(), progress=last_progress(log), log=str(log.relative_to(REPO)))
            write_json(out / "status.json", status)
            try:
                code = child.wait(timeout=15)
                break
            except subprocess.TimeoutExpired:
                pass
    status.update(child_pid=None, progress=last_progress(log), updated_at=now())
    if code:
        raise RuntimeError(f"{name} exited {code}: {log}\n{status['progress']}")
    status["completed_stages"].append(name)
    write_json(out / "status.json", status)
    print(f"{now()} Completed {name}", flush=True)


def evaluation_output(out, status, stage):
    if stage in status["completed_stages"]:
        return REPO / status["outputs"][stage]
    attempt = 1
    while (out / "evaluations" / f"{stage}_{attempt}").exists():
        attempt += 1
    path = out / "evaluations" / f"{stage}_{attempt}"
    status["outputs"][stage] = str(path.relative_to(REPO)).replace("\\", "/")
    return path


def compare(out, status, plan):
    import torch

    check_inputs(plan)
    fold = json.loads((out / "training/fold0/fold_report.json").read_text())
    state = torch.load(out / "training/fold0/best.pt", map_location="cpu", weights_only=True)
    rows, metrics = [], {}
    for dataset, directory in DATASETS.items():
        path = REPO / status["outputs"][f"evaluate_{dataset.lower()}"]
        if dataset == "ATLAS":
            with (path / "predictions.csv").open(encoding="utf-8", newline="") as stream:
                predictions = list(csv.DictReader(stream))
            candidate = dict(
                paths=[r["file"] for r in predictions],
                labels=np.array([("RR", "RG", "NoR").index(r["label"]) for r in predictions]),
                logits=np.array([[float(r[f"logit_{c}"]) for c in ("RR", "RG", "NoR")] for r in predictions]),
            )
        else:
            candidate = np.load(
                path / ("vitb_fold0/predictions.npz" if dataset == "VZC_TLD" else "predictions.npz")
            )
            if dataset == "VZC_TLD":
                snapshot = json.loads((path / "labels_snapshot.json").read_text())
                candidate = published_vzc_predictions(candidate, snapshot)
        with np.load(REFERENCE / dataset / "C/predictions.npz") as old:
            labels, logits = aligned_predictions(dataset, old, candidate)
            reference_report = report(labels, old["logits"])
        new_report = report(labels, logits)
        recorded = json.loads((REPO / f"docs/results/{directory}/report.json").read_text())
        if abs(recorded["metrics"]["mAP"] - reference_report["metrics"]["mAP"]) > 1e-12:
            raise ValueError(f"Baseline {dataset} logits disagree with published metrics")
        metrics[dataset] = dict(baseline=reference_report, candidate=new_report)
        for metric in ("mAP", "acc_bal", "accuracy", "macro_F1", "AP_RR", "AP_RG", "AP_NoR"):
            old_value, new_value = reference_report["metrics"][metric], new_report["metrics"][metric]
            rows.append(
                dict(
                    dataset=dataset,
                    metric=metric,
                    baseline=old_value,
                    candidate=new_value,
                    delta_pp=100 * (new_value - old_value),
                )
            )
        for label in ("RR", "RG", "NoR"):
            old_value = reference_report["per_class"][label]["recall"]
            new_value = new_report["per_class"][label]["recall"]
            rows.append(
                dict(
                    dataset=dataset,
                    metric=f"recall_{label}",
                    baseline=old_value,
                    candidate=new_value,
                    delta_pp=100 * (new_value - old_value),
                )
            )
    old_val = plan["baseline_validation_mAP"]
    val_delta = fold["metrics"]["mAP"] - old_val
    test_deltas = {
        name: r["candidate"]["metrics"]["mAP"] - r["baseline"]["metrics"]["mAP"]
        for name, r in metrics.items()
    }
    recommend = (
        val_delta > 0
        and all(delta >= 0 for delta in test_deltas.values())
        and any(delta > 0 for delta in test_deltas.values())
    )
    result = dict(
        state="complete",
        completed_at=now(),
        fold_indices=[0],
        candidate_checkpoint=str((out / "training/fold0/best.pt").relative_to(REPO)),
        candidate_checkpoint_sha256=sha256_file(out / "training/fold0/best.pt"),
        selected_epoch=state["epoch"],
        head_parameters=sum(t.numel() for t in state["ema"].values()),
        validation=dict(baseline_mAP=old_val, candidate_mAP=fold["metrics"]["mAP"], delta_pp=100 * val_delta),
        datasets=metrics,
        recommend_other_folds=recommend,
        decision_rule=plan["decision_rule"],
        additional_folds_started=False,
        limitations=[
            "Single seed and fold; point estimates do not establish statistical significance.",
            "ATLAS and VZC previously informed development; transfer comparisons are exploratory.",
            "The wider encoder necessarily widens the head input projection; head depth and output width remain fixed.",
        ],
    )
    write_json(out / "comparison.json", result)
    with (out / "comparison.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = [
        "# DINOv3 ViT-B/16 fold-0 pilot",
        "",
        f"Selected EMA epoch: {state['epoch']}. Raw temperature: T=1.",
        "",
        "| Dataset | S+ mAP | B mAP | Change (pp) | S+ balanced accuracy | B balanced accuracy |",
        "|:--|--:|--:|--:|--:|--:|",
    ]
    for dataset, values in metrics.items():
        a, b = values["baseline"]["metrics"], values["candidate"]["metrics"]
        lines.append(
            f"| {dataset} | {100 * a['mAP']:.2f} | {100 * b['mAP']:.2f} | {100 * (b['mAP'] - a['mAP']):+.2f} | {100 * a['acc_bal']:.2f} | {100 * b['acc_bal']:.2f} |"
        )
    lines.extend(
        [
            "",
            f"Validation mAP change: {100 * val_delta:+.2f} percentage points.",
            "",
            f"Recommend testing other folds: {'yes' if recommend else 'no'}. Folds 1–3 were not started.",
            "",
            plan["decision_rule"],
            "",
            *result["limitations"],
        ]
    )
    (out / "comparison.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=REPO / "runs/backbone_vitb_fold0")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--plan", type=Path, help="explicit recovery plan; original plan stays immutable")
    args = parser.parse_args()
    out = args.out.resolve()
    if not out.is_relative_to(REPO / "runs"):
        raise ValueError("Pilot output must stay inside this workspace's runs directory")
    out.mkdir(parents=True, exist_ok=True)
    cfg = load_config(CONFIG)
    default = load_config(REPO / "configs/default.yaml")
    if any(cfg[key] != value for key, value in default.items() if key != "backbone"):
        raise ValueError("Capacity pilot must change only the backbone configuration")
    smoke = json.loads((out / "smoke/report.json").read_text())
    if smoke["status"] != "complete" or smoke["backbone"] != cfg["backbone"]:
        raise ValueError("Run smoke.py for the candidate before launching the pilot")
    plan_path = args.plan.resolve() if args.plan else out / "plan.json"
    if args.plan and not plan_path.is_file():
        raise ValueError("An explicit recovery plan must already exist")
    if plan_path.exists():
        if not args.resume:
            raise ValueError("Existing pilot requires --resume")
        plan = json.loads(plan_path.read_text())
        check_inputs(plan)
    else:
        provenance = json.loads((REPO / "docs/results/provenance.json").read_text())
        if (
            sha256_file(REPO / provenance["checkpoint"]["checkpoint"])
            != provenance["checkpoint"]["checkpoint_sha256"]
        ):
            raise ValueError("Retained baseline checkpoint hash differs")
        plan = dict(
            schema_version=1,
            frozen_at=now(),
            config=cfg,
            backbone=backbone_spec(cfg["backbone"]["hf_id"]),
            fold_indices=[0],
            epochs=cfg["optim"]["epochs"],
            selection="highest city-validation EMA mAP at T=1; earliest tie",
            baseline_checkpoint=provenance["checkpoint"],
            baseline_validation_mAP=provenance["checkpoint"]["validation_mAP"],
            evaluation={
                "DTLD": "all 12453 official test images",
                "ATLAS": "all 528 fixed manual labels, including uncertain",
                "VZC_TLD": "598 published test images; train/all reported separately",
            },
            decision_rule="Recommend further folds only if validation mAP improves and no dataset's test mAP decreases, with at least one test mAP increase. Report all operating metrics regardless. Never launch additional folds automatically.",
            input_sha256=frozen_inputs(cfg, out),
        )
        write_json(plan_path, plan)
    status_path = out / "status.json"
    status = (
        json.loads(status_path.read_text())
        if status_path.exists()
        else dict(started_at=now(), completed_stages=[], outputs={})
    )
    status.update(pid=os.getpid(), state="running", updated_at=now(), child_pid=None)
    write_json(status_path, status)
    try:
        run_stage(
            "train_fold0",
            [
                "scripts/cross_validate.py",
                "--config",
                CONFIG,
                "--out",
                out / "training",
                "--fold-manifest",
                "metadata/dtld_city_folds.json",
                "--runtime-loader",
                "configs/runtime.json",
                "--fold-indices",
                "0",
                "--epochs",
                str(cfg["optim"]["epochs"]),
                "--resume",
            ],
            out,
            status,
            plan,
        )
        ckpt = out / "training/fold0/best.pt"
        for dataset in DATASETS:
            stage = f"evaluate_{dataset.lower()}"
            target = evaluation_output(out, status, stage)
            if dataset == "DTLD":
                command = ["scripts/evaluate.py", "--runtime-loader", "configs/runtime.json"]
            elif dataset == "ATLAS":
                command = [
                    "scripts/evaluate_ood.py",
                    "--labels",
                    "metadata/atlas_labels.json",
                    "--images",
                    "datasets/atlas_relevance_expanded",
                    "--include-uncertain",
                ]
            else:
                command = [
                    "scripts/evaluate_vzc.py",
                    "--model-names",
                    "vitb_fold0",
                    "--batch",
                    str(cfg["optim"]["batch"]),
                ]
            run_stage(
                stage, [*command, "--ckpt", ckpt, "--device", "cuda", "--out", target], out, status, plan
            )
        result = compare(out, status, plan)
        status.update(
            state="complete",
            completed_at=now(),
            stage="complete",
            recommend_other_folds=result["recommend_other_folds"],
            child_pid=None,
        )
        write_json(status_path, status)
        print(f"Comparison saved: {out / 'comparison.md'}", flush=True)
    except Exception as error:
        status.update(state="failed", error=str(error), updated_at=now(), child_pid=None)
        write_json(status_path, status)
        raise


if __name__ == "__main__":
    main()
